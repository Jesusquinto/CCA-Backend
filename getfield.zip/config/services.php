<?php
return [
   
    'google' => [
        'client_id' => '603383718560-k0g8gk5s3vkjv86ev8008bnfpr9v3ocg.apps.googleusercontent.com',
        'client_secret' => 'dZOGO9vu1RrOP8YS2xI7_UU-',
        'redirect' => env('APP_URL').'/auth/adwords/callback'
    ],
];